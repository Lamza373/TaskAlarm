plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "ru.taskalarm.app"
    compileSdk = 35
    defaultConfig {
        applicationId = "ru.taskalarm.app"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
