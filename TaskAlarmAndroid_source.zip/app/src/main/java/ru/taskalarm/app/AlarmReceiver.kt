package ru.taskalarm.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val id = intent.getLongExtra("task_id", -1L)
        val task = TaskDb(context).allTasks().firstOrNull { it.id == id } ?: return
        if (task.completed) return

        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel(
                CHANNEL, "Будильники задач", NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Звуковые напоминания о задачах"
                lockscreenVisibility = Notification.VISIBILITY_PUBLIC
                setSound(null, null) // звук воспроизводится AlarmActivity через поток ALARM
                enableVibration(true)
            })
        }
        val full = PendingIntent.getActivity(context, id.toInt(),
            Intent(context, AlarmActivity::class.java).putExtra("task_id", id),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val notification = if (Build.VERSION.SDK_INT >= 26) {
            Notification.Builder(context, CHANNEL)
        } else {
            @Suppress("DEPRECATION") Notification.Builder(context)
        }.setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("Время выполнить задачу")
            .setContentText(task.title)
            .setCategory(Notification.CATEGORY_ALARM)
            .setPriority(Notification.PRIORITY_MAX)
            .setFullScreenIntent(full, true)
            .setContentIntent(full)
            .setOngoing(true)
            .build()
        nm.notify(id.toInt(), notification)
        try { context.startActivity(Intent(context, AlarmActivity::class.java)
            .putExtra("task_id", id).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)) }
        catch (_: Exception) {}
    }
    companion object { const val CHANNEL = "task_alarm_channel" }
}
