package ru.taskalarm.app

import android.app.Activity
import android.app.NotificationManager
import android.content.Context
import android.media.AudioAttributes
import android.media.Ringtone
import android.media.RingtoneManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import java.util.concurrent.TimeUnit

class AlarmActivity : Activity() {
    private var ringtone: Ringtone? = null
    private var taskId = -1L
    private val handler = Handler(Looper.getMainLooper())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        taskId = intent.getLongExtra("task_id", -1L)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON or
            WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
            WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON)
        val task = TaskDb(this).allTasks().firstOrNull { it.id == taskId }
        val title = TextView(this).apply {
            text = task?.title ?: "Напоминание"
            textSize = 27f; gravity = Gravity.CENTER; setPadding(24, 24, 24, 24)
        }
        val subtitle = TextView(this).apply {
            text = "Пора выполнить задачу"; textSize = 16f; gravity = Gravity.CENTER
        }
        val done = Button(this).apply { text = "Выполнено"; setOnClickListener {
            TaskDb(this@AlarmActivity).setTaskDone(taskId, true)
            AlarmScheduler.cancel(this@AlarmActivity, taskId)
            closeAlarm()
        } }
        val snooze = Button(this).apply { text = "Отложить на 5 минут"; setOnClickListener {
            stopSound()
            val next = System.currentTimeMillis() + TimeUnit.MINUTES.toMillis(5)
            TaskDb(this@AlarmActivity).updateTask(taskId, task?.title ?: "Задача", task?.note ?: "", next, false)
            AlarmScheduler.schedule(this@AlarmActivity, taskId, next)
            closeAlarm()
        } }
        val stop = Button(this).apply { text = "Выключить звук"; setOnClickListener { stopSound(); finish() } }
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            setPadding(28, 40, 28, 40)
            addView(title); addView(subtitle); addView(done); addView(snooze); addView(stop)
        }
        setContentView(layout)
        startSound()
    }

    private fun startSound() {
        try {
            val uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
                ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
            ringtone = RingtoneManager.getRingtone(this, uri)
            ringtone?.audioAttributes = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ALARM)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()
            ringtone?.play()
            handler.postDelayed({ stopSound() }, TimeUnit.MINUTES.toMillis(3))
        } catch (_: Exception) {}
    }
    private fun stopSound() { try { ringtone?.stop() } catch (_: Exception) {} }
    private fun closeAlarm() {
        stopSound()
        (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).cancel(taskId.toInt())
        finish()
    }
    override fun onDestroy() { stopSound(); super.onDestroy() }
}
