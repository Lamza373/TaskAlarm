package ru.taskalarm.app

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

data class TaskItem(
    val id: Long, val title: String, val note: String, val alarmAt: Long,
    val completed: Boolean, val subtasks: List<Subtask>
)
data class Subtask(val id: Long, val title: String, val done: Boolean)

class TaskDb(context: Context) : SQLiteOpenHelper(context, "taskalarm.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE tasks(id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, note TEXT NOT NULL DEFAULT '', alarm_at INTEGER NOT NULL DEFAULT 0, completed INTEGER NOT NULL DEFAULT 0)")
        db.execSQL("CREATE TABLE subtasks(id INTEGER PRIMARY KEY AUTOINCREMENT, task_id INTEGER NOT NULL, title TEXT NOT NULL, done INTEGER NOT NULL DEFAULT 0)")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}

    fun addTask(title: String, note: String, alarmAt: Long, subs: List<String>): Long {
        val db = writableDatabase
        val v = ContentValues().apply {
            put("title", title); put("note", note); put("alarm_at", alarmAt); put("completed", 0)
        }
        val id = db.insert("tasks", null, v)
        subs.filter { it.isNotBlank() }.forEach {
            db.insert("subtasks", null, ContentValues().apply {
                put("task_id", id); put("title", it.trim()); put("done", 0)
            })
        }
        return id
    }

    fun updateTask(id: Long, title: String, note: String, alarmAt: Long, completed: Boolean) {
        writableDatabase.update("tasks", ContentValues().apply {
            put("title", title); put("note", note); put("alarm_at", alarmAt); put("completed", if (completed) 1 else 0)
        }, "id=?", arrayOf(id.toString()))
    }
    fun setTaskDone(id: Long, done: Boolean) {
        writableDatabase.update("tasks", ContentValues().apply { put("completed", if (done) 1 else 0) }, "id=?", arrayOf(id.toString()))
    }
    fun setSubtaskDone(id: Long, done: Boolean) {
        writableDatabase.update("subtasks", ContentValues().apply { put("done", if (done) 1 else 0) }, "id=?", arrayOf(id.toString()))
    }
    fun addSubtask(taskId: Long, title: String) {
        writableDatabase.insert("subtasks", null, ContentValues().apply {
            put("task_id", taskId); put("title", title); put("done", 0)
        })
    }
    fun deleteTask(id: Long) {
        writableDatabase.delete("subtasks", "task_id=?", arrayOf(id.toString()))
        writableDatabase.delete("tasks", "id=?", arrayOf(id.toString()))
    }
    fun allTasks(): List<TaskItem> {
        val result = mutableListOf<TaskItem>()
        val c = readableDatabase.rawQuery("SELECT id,title,note,alarm_at,completed FROM tasks ORDER BY completed ASC, alarm_at ASC, id DESC", null)
        c.use {
            while (it.moveToNext()) {
                val id = it.getLong(0)
                val subs = mutableListOf<Subtask>()
                readableDatabase.rawQuery("SELECT id,title,done FROM subtasks WHERE task_id=? ORDER BY id", arrayOf(id.toString())).use { s ->
                    while (s.moveToNext()) subs.add(Subtask(s.getLong(0), s.getString(1), s.getInt(2) == 1))
                }
                result.add(TaskItem(id, it.getString(1), it.getString(2), it.getLong(3), it.getInt(4) == 1, subs))
            }
        }
        return result
    }
    fun activeAlarms(): List<Pair<Long, Long>> {
        val out = mutableListOf<Pair<Long, Long>>()
        readableDatabase.rawQuery("SELECT id,alarm_at FROM tasks WHERE completed=0 AND alarm_at>0", null).use {
            while (it.moveToNext()) out.add(it.getLong(0) to it.getLong(1))
        }
        return out
    }
}
