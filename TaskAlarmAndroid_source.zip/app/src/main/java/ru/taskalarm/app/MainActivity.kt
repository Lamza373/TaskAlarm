package ru.taskalarm.app

import android.Manifest
import android.app.Activity
import android.app.AlarmManager
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.*
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : Activity() {
    private lateinit var db: TaskDb
    private lateinit var list: LinearLayout
    private var chosenAlarm = 0L
    private val fmt = SimpleDateFormat("dd.MM.yyyy HH:mm", Locale("ru"))

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        db = TaskDb(this)
        requestPermissionsIfNeeded()
        showHome()
    }

    private fun requestPermissionsIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 10)
        }
        if (Build.VERSION.SDK_INT >= 31) {
            val am = getSystemService(ALARM_SERVICE) as AlarmManager
            if (!am.canScheduleExactAlarms()) {
                try { startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,
                    Uri.parse("package:$packageName"))) } catch (_: Exception) {}
            }
        }
    }

    private fun showHome() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(20, 24, 20, 12)
        }
        root.addView(TextView(this).apply { text = "Мои задачи"; textSize = 28f })
        root.addView(TextView(this).apply { text = "Заметки, чек-листы и будильники"; textSize = 14f })
        root.addView(Button(this).apply { text = "+ Новая задача"; setOnClickListener { showAddDialog() } })
        val scroll = ScrollView(this)
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(Button(this).apply { text = "Настройки звука и разрешений"; setOnClickListener { showSoundSettings() } })
        setContentView(root)
        refreshTasks()
    }

    private fun refreshTasks() {
        list.removeAllViews()
        val tasks = db.allTasks()
        if (tasks.isEmpty()) {
            list.addView(TextView(this).apply { text = "Пока нет задач. Нажмите «Новая задача»."; setPadding(8, 28, 8, 28) })
        }
        tasks.forEach { task ->
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; setPadding(12, 12, 12, 12)
                setBackgroundColor(if (task.completed) 0xFFECECEC.toInt() else 0xFFF2EFF8.toInt())
            }
            val heading = CheckBox(this).apply {
                text = task.title; textSize = 18f; isChecked = task.completed
                setOnCheckedChangeListener { _, checked ->
                    db.setTaskDone(task.id, checked)
                    if (checked) AlarmScheduler.cancel(this@MainActivity, task.id)
                    refreshTasks()
                }
            }
            card.addView(heading)
            if (task.note.isNotBlank()) card.addView(TextView(this).apply { text = task.note; setPadding(8, 2, 8, 4) })
            if (task.alarmAt > 0 && !task.completed) {
                card.addView(TextView(this).apply { text = "Будильник: ${fmt.format(Date(task.alarmAt))}" })
            }
            task.subtasks.forEach { sub ->
                card.addView(CheckBox(this).apply {
                    text = "   ${sub.title}"; isChecked = sub.done
                    setOnCheckedChangeListener { _, checked -> db.setSubtaskDone(sub.id, checked) }
                })
            }
            val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            actions.addView(Button(this).apply { text = "+ Подпункт"; setOnClickListener {
                val input = EditText(this@MainActivity).apply { hint = "Название подпункта" }
                android.app.AlertDialog.Builder(this@MainActivity).setTitle("Добавить подпункт").setView(input)
                    .setPositiveButton("Добавить") { _, _ ->
                        if (input.text.isNotBlank()) { db.addSubtask(task.id, input.text.toString()); refreshTasks() }
                    }.setNegativeButton("Отмена", null).show()
            } })
            actions.addView(Button(this).apply { text = "Удалить"; setOnClickListener {
                db.deleteTask(task.id); AlarmScheduler.cancel(this@MainActivity, task.id); refreshTasks()
            } })
            card.addView(actions)
            val params = LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, 12, 0, 0) }
            list.addView(card, params)
        }
    }

    private fun showAddDialog() {
        val panel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(20, 8, 20, 4) }
        val title = EditText(this).apply { hint = "Название задачи" }
        val note = EditText(this).apply { hint = "Заметка или описание"; minLines = 2; gravity = Gravity.TOP }
        val subs = EditText(this).apply { hint = "Подпункты — каждый с новой строки"; minLines = 2; gravity = Gravity.TOP }
        val alarmLabel = TextView(this).apply { text = "Будильник не установлен"; setPadding(0, 12, 0, 4) }
        val alarmButton = Button(this).apply { text = "Установить дату и время" }
        chosenAlarm = 0L
        alarmButton.setOnClickListener {
            val now = Calendar.getInstance()
            DatePickerDialog(this, { _, y, m, d ->
                TimePickerDialog(this, { _, h, min ->
                    val c = Calendar.getInstance().apply { set(y, m, d, h, min, 0); set(Calendar.MILLISECOND, 0) }
                    chosenAlarm = c.timeInMillis
                    alarmLabel.text = "Сработает: ${fmt.format(Date(chosenAlarm))}"
                }, now.get(Calendar.HOUR_OF_DAY), now.get(Calendar.MINUTE), true).show()
            }, now.get(Calendar.YEAR), now.get(Calendar.MONTH), now.get(Calendar.DAY_OF_MONTH)).show()
        }
        panel.addView(title); panel.addView(note); panel.addView(subs); panel.addView(alarmButton); panel.addView(alarmLabel)
        android.app.AlertDialog.Builder(this).setTitle("Новая задача").setView(panel)
            .setPositiveButton("Сохранить") { _, _ ->
                if (title.text.isBlank()) {
                    Toast.makeText(this, "Введите название задачи", Toast.LENGTH_SHORT).show()
                } else {
                    val id = db.addTask(title.text.toString(), note.text.toString(), chosenAlarm,
                        subs.text.toString().lines())
                    if (chosenAlarm > System.currentTimeMillis()) AlarmScheduler.schedule(this, id, chosenAlarm)
                    refreshTasks()
                }
            }.setNegativeButton("Отмена", null).show()
    }

    private fun showSoundSettings() {
        val message = "Будильник использует системный звуковой поток ALARM. Проверьте громкость «Будильник» кнопками громкости или в настройках звука телефона. " +
            "Режим «Не беспокоить» может блокировать сигнал, если в нём запрещены будильники. Разрешение на точные будильники и уведомления нужно выдать приложению."
        android.app.AlertDialog.Builder(this).setTitle("Звук будильника").setMessage(message)
            .setPositiveButton("Открыть настройки приложения") { _, _ ->
                startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
            }.setNegativeButton("Закрыть", null).show()
    }
}
