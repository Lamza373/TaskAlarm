package ru.taskalarm.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        TaskDb(context).activeAlarms().forEach { (id, at) ->
            if (at > System.currentTimeMillis()) AlarmScheduler.schedule(context, id, at)
        }
    }
}
